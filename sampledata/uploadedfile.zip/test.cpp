#include <iostream>

int main(int argc, const char **argv) {
    std::cout << "Hello World!" << std::endl;
    for (int i = argc - 1; i >= 0; --i) {
        std::cout << argv[i] << std::endl;
    }
    return 0;
}
